// End-to-end smoke test of the REAL App.js in headless Chromium.
//   * native modules are replaced by stand-ins (tests/browser/stubs)
//   * the database is a real SQLite (node:sqlite) reached through a bridge
// Run:  node tests/browser/run.mjs      (needs Node 22+, playwright + esbuild)
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';
import { DatabaseSync } from 'node:sqlite';
import { bundle } from './build.mjs';

const require = createRequire('/opt/npm-tools/package.json');
const { chromium } = require('playwright');

const out = fs.mkdtempSync(path.join(os.tmpdir(), 'kj-browser-'));
const bundlePath = path.join(out, 'bundle.js');
await bundle(bundlePath);

const raw = new DatabaseSync(':memory:');
const q = (sql, ...p) => raw.prepare(sql).all(...p).map((r) => ({ ...r }));
const one = (sql, ...p) => q(sql, ...p)[0] || null;

const browser = await chromium.launch({ args: ['--no-sandbox'], executablePath: process.env.CHROME_PATH || undefined });
const page = await browser.newPage({ viewport: { width: 412, height: 860 } });
page.setDefaultTimeout(5000);
await page.exposeFunction('__db', (op, sql, params) => {
  if (op === 'exec') { raw.exec(sql); return null; }
  if (op === 'run') {
    const r = raw.prepare(sql).run(...params);
    return { lastInsertRowId: Number(r.lastInsertRowid), changes: r.changes };
  }
  if (op === 'all') return raw.prepare(sql).all(...params).map((r) => ({ ...r }));
  if (op === 'first') { const r = raw.prepare(sql).get(...params); return r ? { ...r } : null; }
  throw new Error('bad op ' + op);
});
await page.setContent('<!doctype html><html><body style="margin:0"><div id="root"></div></body></html>');
await page.addScriptTag({ path: bundlePath });

let passed = 0;
const failures = [];
async function step(name, fn) {
  try { await fn(); passed++; console.log('  ok  ', name); }
  catch (e) {
    failures.push(name);
    console.log('  FAIL', name, '\n      ', String(e.message).split('\n').slice(0, 40).join(' | '), process.env.KJ_DEBUG ? String(e.stack).split('\n').filter((l) => l.includes('run.mjs')).slice(0, 2).join(' ') : '');
    if (process.env.KJ_DEBUG) {
      console.log('      page errors:', JSON.stringify((await errors().catch(() => [])).slice(0, 3)).slice(0, 600));
      console.log('      page text  :', JSON.stringify((await bodyText().catch(() => '')).slice(0, 400)));
    }
  }
}
page.on('console', (m) => { if (process.env.KJ_DEBUG && (m.text().includes('backup failed') || m.text().includes('share failed') || m.text().startsWith('DEL-'))) console.log('      CONSOLE', m.text().slice(0, 500)); });

const editorFrame = async () => {
  await page.waitForSelector('[data-testid="editor-frame"]');
  const handle = await page.$('[data-testid="editor-frame"]');
  const fr = await handle.contentFrame();
  await fr.waitForSelector('#ed');
  return fr;
};
async function typeBody(txt) {
  const fr = await editorFrame();
  await fr.click('#ed');
  await page.keyboard.type(txt);
}
const editFromPreview = async () => { await page.locator('[data-testid="entry-preview"] [role="button"][aria-label="Edit"]').click(); await wait(200); };
const closePreview = async () => { const pv = page.locator('[data-testid="entry-preview"]'); await wait(150); if (await pv.count()) { await pv.locator('[role="button"][aria-label="Back"]').click(); await wait(150); } };
const bodyHtmlInEditor = async () => (await editorFrame()).evaluate(() => document.getElementById('ed').innerHTML);
const wait = (ms) => page.waitForTimeout(ms);
const text = (t, opts = {}) => page.getByText(t, { exact: true, ...opts });
const NO_MOOD = 'No mood check-ins yet';
const label = (l) => (l === 'tab-settings' ? page.locator('[aria-label="Settings"]').first() : l.startsWith('tab-') ? page.locator(`[data-testid="${l}"]`) : page.locator(`[aria-label="${l}"]`));
const bodyText = () => page.evaluate(() => document.body.innerText);
const errors = () => page.evaluate(() => window.__errors);
async function waitForText(t, timeout = 4000) {
  await page.waitForFunction((s) => document.body.innerText.includes(s), t, { timeout });
}
async function waitFor(fn, timeout = 4000) {
  const start = Date.now();
  for (;;) {
    const v = await fn();
    if (v) return v;
    if (Date.now() - start > timeout) throw new Error('waitFor timed out');
    await wait(80);
  }
}
const putFile = (uri, bytes = 3000) =>
  page.evaluate(([u, n]) => window.__files.set(u, 'A'.repeat(n)), [uri, bytes]);
const files = () => page.evaluate(() => [...window.__files.keys()]);


// Fake Leaflet (no internet in the sandbox): enough of the API for our page script.
const FAKE_LEAFLET = `(function(){
  function Map_(id){ this.el=document.getElementById(id); window.__mapCalls=[]; this.h={}; }
  Map_.prototype.setView=function(c,z){window.__mapCalls.push(['setView',c,z]);return this;};
  Map_.prototype.fitBounds=function(b,o){window.__mapCalls.push(['fitBounds',b.length]);return this;};
  Map_.prototype.on=function(t,cb){this.h[t]=cb;window.__fire=function(lat,lng){this.h.click&&this.h.click({latlng:{lat:lat,lng:lng}});}.bind(this);return this;};
  window.L={ map:function(id){return new Map_(id);}, tileLayer:function(u){window.__tile=u;return {addTo:function(){}};},
    divIcon:function(o){return o;},
    marker:function(ll,o){var m={setLatLng:function(x){window.__pin=x;return m;},getLatLng:function(){return {lat:0,lng:0};},addTo:function(map){var d=document.createElement('div');d.className='leaflet-marker-icon';d.innerHTML=o.icon.html;d.addEventListener('click',function(e){e.stopPropagation();m.cb&&m.cb();});map.el.appendChild(d);return m;},on:function(t,cb){m.cb=cb;return m;}};return m;} };
})();`;

console.log('boot');
await step('Onboarding: welcome, companion, passcode, log in, reminders, done; language switches; every page can be skipped through; finishing is remembered', async () => {
  const mainBtn = (label) => page.locator('[role="button"]').filter({ hasText: new RegExp(`^${label}$`) }).last();
  await waitForText('Welcome to Kitty Journal');
  await waitForText('Press Next to get started');
  // language: Persian re-renders the intro in Persian, English brings it back
  await text('فارسی', { exact: true }).first().click();
  await waitForText('به کیتی ژورنال خوش آمدی');
  await text('English', { exact: true }).first().click();
  await waitForText('Welcome to Kitty Journal');
  await mainBtn('Next').click();
  await waitForText('Your life companion');
  await waitForText('confide in privately');
  await mainBtn('Next').click();
  // privacy page is only an introduction: no lock button here
  await waitForText('Safe and private');
  await waitForText('Add a passcode to keep your diary private');
  assert.equal(await page.locator('[role="button"]').filter({ hasText: /Add passcode/ }).count(), 0, 'no passcode button in the intro');
  await mainBtn('Next').click();
  // log in page: only a button for now
  await waitForText('Keep your memories forever');
  assert.equal(await page.locator('[role="button"]').filter({ hasText: /^Log in$/ }).count(), 1, 'login button');
  await mainBtn('Skip').click();
  await waitForText('Get notified');
  // permission denied: explained, nothing scheduled, can still continue
  await page.evaluate(() => { window.__notifPerm = 'denied'; });
  await text('Remind me to write', { exact: true }).first().click();
  await waitForText('Notifications are turned off for Kitty Journal');
  assert.equal(await page.evaluate(() => window.__scheduled.length), 0);
  // the time can be chosen here; with permission granted the reminder uses it
  await page.evaluate(() => { window.__notifPerm = 'granted'; });
  await page.locator('[role="button"][aria-label="Hour +"]').first().click();
  await page.locator('[role="button"][aria-label="Minute +"]').first().click();
  await text('Remind me to write', { exact: true }).first().click();
  await waitFor(() => { const r = one("SELECT value FROM app_settings WHERE key='reminder'"); return r && JSON.parse(r.value).hour === 21 && JSON.parse(r.value).minute === 5; });
  await mainBtn('Next').click();
  await waitForText('Congratulations!');
  await waitForText('You can start using the app');
  await text('Start writing', { exact: true }).first().click();
  await waitForText('Recent entries');
  assert.equal(JSON.parse(one("SELECT value FROM app_settings WHERE key='onboardingDone'").value), true);
  assert.deepEqual(await errors(), []);
});
await step('app boots, migrations run, home renders without errors', async () => {
  await waitForText('Kitty Journal');
  await waitForText('Recent entries');
  const v = one('PRAGMA user_version').user_version;
  assert.ok(v >= 4, 'user_version ' + v);
  assert.deepEqual(await errors(), []);
});

console.log('entry: text, tag, feelings, place, photo');
await step('Plan: free users get the simple app (locks and teasers); switching to Premium in Settings unlocks everything', async () => {
  const later = () => page.locator('[data-testid="premium-later"]').click();
  assert.equal(await page.evaluate(() => 1), 1);
  await label('tab-settings').click();
  await waitForText('Your plan');
  assert.equal(await page.locator('[data-testid="premium-prompt"]').count(), 0);
  // app lock is Premium
  await page.setViewportSize({ width: 412, height: 1700 }); await wait(400);
  await text('App lock', { exact: true }).first().click();
  await page.locator('[data-testid="premium-prompt"]').waitFor();
  await waitForText('Locking the app with a PIN or fingerprint is part of Premium');
  await later();
  await page.setViewportSize({ width: 412, height: 860 }); await wait(300);
  // only the Sage theme is free
  await text('Appearance', { exact: true }).first().click();
  await page.locator('[data-testid="theme-rose"]').click();
  await waitForText('All colour themes are part of Premium');
  await later();
  assert.equal(one("SELECT value FROM app_settings WHERE key='theme'"), null, 'a locked theme is not saved');
  await page.evaluate(() => window.__pressBack()); await wait(250);
  // Memories is Premium
  await label('tab-memories').click();
  await page.locator('[data-testid="premium-locked"]').waitFor();
  for (const [tabName, hint] of [['Map', 'with your photos as pins'], ['Places', 'Give them names'], ['Photos', 'on one wall']]) {
    await text(tabName, { exact: true }).first().dispatchEvent('click');
    await waitForText(hint);
  }
  await text('See Premium', { exact: true }).waitFor();
  // Insights is the simple version
  await label('tab-insights').click();
  await waitForText('Showing the last 30 days');
  assert.equal(await text('Entries by month', { exact: true }).count(), 0, 'no monthly chart for free');
  assert.ok((await bodyText()).includes('Full insights'), 'teaser for the rest');
  await waitForText('Mood distribution');
  // switch to Premium (testing switch)
  await label('tab-settings').click();
  await text('Premium', { exact: true }).first().click();
  await waitFor(() => (one("SELECT value FROM app_settings WHERE key='premium'") || {}).value === 'true');
  await label('tab-memories').click();
  await waitFor(async () => (await page.locator('[data-testid="premium-locked"]').count()) === 0);
  await label('tab-insights').click();
  await text('Entries by month', { exact: true }).waitFor();
  assert.deepEqual(await errors(), []);
  await label('tab-home').click();
  await waitForText('Recent entries');
});
await step('new entry autosaves text and shows "Saved" only after commit', async () => {
  await label('New entry').click();
  await page.getByPlaceholder('A title for today (optional)').fill('Istanbul day');
  await typeBody('Walked by the water and took photos.');
  await waitFor(() => one("SELECT * FROM entries WHERE title='Istanbul day'"));
  await waitForText('Saved');
  const e = one("SELECT * FROM entries WHERE title='Istanbul day'");
  assert.equal(e.body, 'Walked by the water and took photos.');
  assert.ok(e.uuid && e.uuid.length === 32);
});
await step('tag is added with Enter and stored once', async () => {
  const tagInput = page.getByPlaceholder('Add a tag…');
  await tagInput.fill('travel');
  await tagInput.press('Enter');
  await tagInput.fill('Travel');
  await tagInput.press('Enter'); // duplicate (case-insensitive) is ignored
  await waitFor(() => one('SELECT COUNT(*) AS n FROM entry_tags').n === 1);
  assert.equal(q('SELECT * FROM tags').length, 1);
});
await step('secondary feeling with strength is stored by machine key', async () => {
  await text('Calm', { exact: true }).first().click();
  await label('Strength 4 of 5').click();
  await waitFor(() => one("SELECT * FROM entry_emotions WHERE emotion_key='calm'"));
  await waitFor(() => one("SELECT intensity FROM entry_emotions WHERE emotion_key='calm'").intensity === 4);
});
await step('"use current location" saves coordinates + name', async () => {
  await text('Use current location').click();
  await waitFor(() => one('SELECT * FROM locations'));
  const l = one('SELECT * FROM locations');
  assert.equal(Math.round(l.latitude * 1000), 41008);
  assert.equal(l.name, 'Galata Tower');
});
await step('denied location permission shows a message, typed name still works', async () => {
  await label('Remove place').click();
  await waitFor(() => !one('SELECT * FROM locations'));
  await page.evaluate(() => { window.__location.granted = false; });
  await text('Use current location').click();
  await waitForText('Location permission was not granted');
  await page.getByPlaceholder('Where were you? (optional)').fill('Kadıköy pier');
  await waitFor(() => one("SELECT * FROM locations WHERE name='Kadıköy pier'"));
  assert.equal(one('SELECT latitude FROM locations').latitude, null);
  // restore a real fix for the rest of the run
  await page.evaluate(() => { window.__location.granted = true; });
  await text('Use current location').click();
  await waitFor(() => one('SELECT latitude FROM locations').latitude != null);
});
await step('choose the place on a map: tap, confirm, coordinates and name are saved', async () => {
  await page.route('**/leaflet.js', (r) => r.fulfill({ contentType: 'application/javascript', body: FAKE_LEAFLET }));
  await page.route('**/leaflet.css', (r) => r.fulfill({ contentType: 'text/css', body: '' }));
  await label('Remove place').click();
  await waitFor(() => !one('SELECT * FROM locations'));
  await page.evaluate(() => { window.__nextReverse = null; });
  await text('Choose on map').dispatchEvent('click');
  await waitForText('Choose a place on the map');
  const frame = page.frameLocator('[data-testid="map-frame"]').last();
  await frame.locator('#map').waitFor();
  await waitForText('Tap the map to drop a pin');
  assert.equal(await text('Use this place').count(), 1);
  const f = await (await page.locator('[data-testid="map-frame"]').last().elementHandle()).contentFrame();
  await f.waitForFunction(() => typeof window.__fire === 'function');
  await f.evaluate(() => window.__fire(41.1234, 29.0567));
  await waitForText('41.12340, 29.05670');
  await text('Use this place').dispatchEvent('click');
  await waitFor(() => one('SELECT * FROM locations'));
  const l = one('SELECT * FROM locations');
  assert.equal(Math.round(l.latitude * 10000), 411234);
  assert.equal(Math.round(l.longitude * 10000), 290567);
  await waitFor(() => one('SELECT * FROM locations').name === 'Galata Tower');
  // back to the state the next steps expect: typed name + the device fix
  await page.getByPlaceholder('Where were you? (optional)').fill('Kadıköy pier');
  await text('Use current location').click();
  await waitFor(() => Math.round(one('SELECT latitude FROM locations').latitude * 1000) === 41008);
  assert.equal(one('SELECT name FROM locations').name, 'Kadıköy pier');
});
await step('photo: picked, copied, thumbnailed, row inserted (big image is re-encoded)', async () => {
  await putFile('file:///cache/pick1.jpg', 3 * 1024 * 1024 + 50);
  await page.evaluate(() => { window.__nextPick = [{ uri: 'file:///cache/pick1.jpg', width: 4000, height: 3000, mimeType: 'image/jpeg' }]; });
  await text('Add photos').click();
  await waitFor(() => one('SELECT * FROM attachments'));
  const a = one('SELECT * FROM attachments');
  const f = await files();
  assert.ok(f.includes('file:///docs/attachments/' + a.file_name), 'main file stored');
  assert.ok(a.thumb_name && f.includes('file:///docs/attachments/' + a.thumb_name), 'thumbnail stored');
  assert.ok(a.width <= 2048 && a.height <= 2048, 'resized to max edge');
  await waitForText('1 added');
});
await step('photo picker cancelled: nothing changes', async () => {
  const before = q('SELECT * FROM attachments').length;
  await page.evaluate(() => { window.__nextPick = []; });
  await text('Add photos').click();
  await wait(300);
  assert.equal(q('SELECT * FROM attachments').length, before);
});
await step('photo: import failure leaves no row and no stray files', async () => {
  const before = (await files()).length;
  await page.evaluate(() => { window.__nextPick = [{ uri: 'file:///cache/does-not-exist.jpg', width: 800, height: 600 }]; });
  await text('Add photos').click();
  await waitForText('could not be added');
  assert.equal(q('SELECT * FROM attachments').length, 1);
  assert.equal((await files()).length, before);
});

console.log('home list and memories');
await step('closing the editor shows the entry with photo count, place and feeling', async () => {
  await text('Done').click();
  await waitFor(async () => (await bodyText()).includes('Istanbul day'));
  const t = await bodyText();
  assert.ok(t.includes('#travel'));
  assert.ok(t.includes('Kadıköy pier'));
  assert.equal(await page.locator('[data-icon="Image"]').count() >= 1, true);
});
await step('Memories: photo grid + places list + open in maps', async () => {
  await label('tab-memories').click();
  await waitFor(async () => (await page.locator('img').count()) >= 1);
  assert.ok((await bodyText()).includes('1 photos'));
  await text('Places').click();
  await waitForText('Kadıköy pier');
  await text('Open in maps').click();
  await waitFor(async () => (await page.evaluate(() => window.__opened || [])).length === 1);
  const url = (await page.evaluate(() => window.__opened))[0];
  assert.ok(url.startsWith('geo:41.0082,28.9784'), url);
});
await step('opening an entry from Memories opens the editor with its data', async () => {
  await text('View entry').click();
  await editFromPreview();
  assert.equal(await page.getByPlaceholder('A title for today (optional)').inputValue(), 'Istanbul day');
  await text('Done').click(); await closePreview();
});

await step('Memories map: photo marker, tap opens the entries of that place', async () => {
  await page.route('**/leaflet.js', (r) => r.fulfill({ contentType: 'application/javascript', body: FAKE_LEAFLET }));
  await page.route('**/leaflet.css', (r) => r.fulfill({ contentType: 'text/css', body: '' }));
  // the stand-in thumbnail is as big as the original; make it realistically small
  await page.evaluate(([n]) => { window.__files.set('file:///docs/attachments/' + n, 'AAAA'); }, [one('SELECT thumb_name FROM attachments').thumb_name]);
  await label('tab-memories').click();
  await text('Map').click();
  const frame = page.frameLocator('[data-testid="map-frame"]');
  await frame.locator('.leaflet-marker-icon').first().waitFor();
  assert.equal(await frame.locator('.leaflet-marker-icon').count(), 1);
  assert.equal(await frame.locator('.leaflet-marker-icon img').count(), 1, 'marker shows the entry photo');
  await waitForText('Tap a photo on the map');
  await frame.locator('.leaflet-marker-icon').first().click();
  await waitForText('1 entries here');
  assert.ok((await bodyText()).includes('Istanbul day'));
  await text('Istanbul day').last().click();
  await editFromPreview();
  assert.equal(await page.getByPlaceholder('A title for today (optional)').inputValue(), 'Istanbul day');
  await text('Done').click(); await closePreview();
});

await step('naming places: Memories list, map panel and entry editor; no add button on Memories', async () => {
  raw.exec("INSERT INTO entries (uuid,title,body,journal_date,favorite,pinned,created_at,updated_at) VALUES ('cccccccccccccccccccccccccccccc01','unnamed trip','b','2026-10-20',0,0,'t','2026-10-20T00:00:00Z')");
  const eid = one("SELECT id FROM entries WHERE title='unnamed trip'").id;
  raw.exec(`INSERT INTO locations (uuid,entry_id,latitude,longitude,name,address,created_at) VALUES ('dddddddddddddddddddddddddddddd01',${eid},40.5,29.5,'','','t')`);
  await label('tab-home').click();
  await label('tab-memories').click();
  assert.equal(await label('New entry').count(), 0, 'no floating add button on Memories');
  await text('Places').click();
  await waitForText('Unnamed place');
  await page.locator('[aria-label="Name this place"]').first().click();
  await page.getByPlaceholder('Where were you? (optional)').fill('Bosphorus bridge');
  await text('Save name').click();
  await waitFor(() => one("SELECT name FROM locations WHERE entry_id=" + eid).name === 'Bosphorus bridge');
  await waitForText('Place name saved');
  await waitForText('Bosphorus bridge');
  // map panel: rename the group again
  await text('Map').click();
  const frame = page.frameLocator('[data-testid="map-frame"]');
  await frame.locator('.leaflet-marker-icon').nth(1).waitFor();
  await frame.locator('.leaflet-marker-icon').nth(1).click();
  await waitForText('Bosphorus bridge');
  await page.locator('[aria-label="Edit name"]').first().click();
  await page.getByPlaceholder('Where were you? (optional)').fill('Bridge');
  await text('Save name').click();
  await waitFor(() => one("SELECT name FROM locations WHERE entry_id=" + eid).name === 'Bridge');
  // editor: a place saved without a name shows an obvious prompt
  await label('tab-home').click();
  await page.evaluate(() => { window.__location.place = {}; });
  await label('New entry').click();
  await page.getByPlaceholder('A title for today (optional)').fill('nameless spot');
  await text('Use current location').click();
  await waitForText('This place has no name yet');
  await page.getByPlaceholder('Where were you? (optional)').fill('Corner cafe');
  await waitFor(async () => !(await bodyText()).includes('This place has no name yet'));
  await waitFor(() => one("SELECT name FROM locations WHERE name='Corner cafe'"));
  await text('Done').click();
  await page.evaluate(() => { window.__location.place = { name: 'Galata Tower', street: 'Galata', city: 'Istanbul', region: 'Istanbul', country: 'Türkiye' }; });
  raw.exec("DELETE FROM entries WHERE title IN ('unnamed trip','nameless spot')");
});

await step('Backup (B1): ZIP + JSON export, share sheet, last-backup status', async () => {
  // some data to back up
  raw.exec("INSERT INTO entries (uuid,title,body,journal_date,favorite,pinned,created_at,updated_at) VALUES ('eeeeeeeeeeeeeeeeeeeeeeeeeeeeee01','backup me','text','2026-10-21',0,0,'t','t')");
  // the fake fs holds placeholder photo bytes; make them valid base64 like real files
  await page.evaluate(() => { for (const [k, v] of window.__files) { if (/\.(jpg|jpeg|png|webp)$/i.test(k)) window.__files.set(k, 'QUJDRA'.repeat(Math.ceil(v.length / 6)).slice(0, Math.floor(v.length / 4) * 4 || 4)); } });
  await label('tab-home').click();
  await label('tab-settings').click();
  await text('Backup & restore').dispatchEvent('click');
  await waitForText('No backup yet');
  await text('Full backup (.zip)', { exact: true }).last().click();
  await waitForText('Backup ready');
  const f = await files();
  const zipUri = f.find((u) => u.includes('/backups/') && u.endsWith('.zip'));
  assert.ok(zipUri, 'zip stored in the private backups folder');
  const head = await page.evaluate((u) => window.__files.get(u).slice(0, 4), zipUri);
  assert.equal(head, 'UEsD', 'file is a real ZIP');
  assert.ok((await bodyText()).match(/\d+ entries · \d+ photos/), 'counts shown');
  // nothing counts as backed up until the share sheet was opened
  assert.equal(await page.evaluate(() => window.__shared.length), 0);
  assert.equal((one("SELECT value FROM app_settings WHERE key='lastBackupAt'") || {}).value, undefined);
  // save to a user-picked folder (Downloads) via the system picker
  await page.evaluate(() => { window.__safDeny = true; });
  await text('Save to this phone').click();
  await wait(300);
  assert.equal((one("SELECT value FROM app_settings WHERE key='lastBackupAt'") || {}).value, undefined, 'cancelled picker is not a backup');
  await page.evaluate(() => { window.__safDeny = false; });
  await text('Save to this phone').click();
  await waitForText('Saved to the folder you chose');
  const saved = (await files()).find((u) => u.startsWith('content://downloads/'));
  assert.ok(saved && saved.endsWith('.zip'), 'zip written into the chosen folder');
  assert.equal((await page.evaluate((u) => window.__files.get(u), saved)).slice(0, 4), 'UEsD');
  await waitFor(() => one("SELECT value FROM app_settings WHERE key='lastBackupAt'"));
  await page.evaluate(() => { for (const k of [...window.__files.keys()]) if (k.startsWith('content://')) window.__files.delete(k); });
  raw.exec("DELETE FROM app_settings WHERE key='lastBackupAt'");
  await text('Share / save a copy').click();
  await waitFor(async () => (await page.evaluate(() => window.__shared.length)) === 1);
  await waitFor(() => one("SELECT value FROM app_settings WHERE key='lastBackupAt'"));
  await waitForText('Last backup saved');
  // JSON export: text only, valid, no photo files
  await text('Text export (.json)', { exact: true }).last().click();
  await waitForText('text only');
  const jsonUri = (await files()).find((u) => u.includes('/backups/') && u.endsWith('.json'));
  const parsed = JSON.parse(await page.evaluate((u) => window.__files.get(u), jsonUri));
  assert.equal(parsed.includesAttachmentFiles, false);
  assert.ok(parsed.data.entries.some((e) => e.title === 'backup me'));
  // sharing unavailable: a clear message, and no false "backed up"
  await page.evaluate(() => { window.__shareAvailable = false; });
  const before = one("SELECT value FROM app_settings WHERE key='lastBackupAt'").value;
  await page.waitForTimeout(1100);
  await text('Share / save a copy').click();
  await waitForText('Sharing is not available');
  assert.equal(one("SELECT value FROM app_settings WHERE key='lastBackupAt'").value, before);
  await page.evaluate(() => { window.__shareAvailable = true; });
  raw.exec("DELETE FROM entries WHERE title='backup me'");
  assert.deepEqual(await errors(), []);
  await page.evaluate(() => window.__pressBack()); await wait(250); // backup -> settings
  await page.evaluate(() => window.__pressBack()); await wait(250); // settings closed
  await waitForText('Recent entries');
});

console.log('B2a: restore preview');
await step('Restore (B2a): restore card visible; cancel → no change; bad file → error', async () => {
  await label('tab-settings').click();
  await text('Backup & restore').dispatchEvent('click');
  await waitForText('Restore from a file');

  const restoreBtn = () => page.locator('[role="button"]').filter({ hasText: 'Restore from a file' }).first();

  // ── 1. cancel the picker → no preview ─────────────────────────────────
  await restoreBtn().click();
  await wait(700);
  assert.ok(!(await bodyText()).includes('What is in this file'), 'cancelled pick: no preview');

  // ── 2. pick a non-backup file → error ─────────────────────────────────
  // Store as plain text (stub ignores encoding, returns stored value as-is).
  // parseBackup sees text='hello world' → corrupt-json → shows errCorrupt.
  await page.evaluate(() => {
    window.__files.set('file:///cache/notabackup.txt', 'hello world');
    window.__nextPickResult = { name: 'notabackup.txt', uri: 'file:///cache/notabackup.txt' };
  });
  await restoreBtn().click();
  // errCorrupt: 'This file is damaged and cannot be read.'
  await waitForText('damaged and cannot be read');

  assert.deepEqual(await errors(), []);
  await page.evaluate(() => window.__pressBack()); await wait(250);
  await page.evaluate(() => window.__pressBack()); await wait(250);
  await waitForText('Recent entries');
});

await step('Restore (B2b): JSON merge adds missing entry, keeps existing; replace asks to confirm', async () => {
  raw.exec("INSERT INTO entries (uuid,title,body,journal_date,favorite,pinned,created_at,updated_at) VALUES ('b2b0000000000000000000000000000a','restore me','text','2026-10-22',0,0,'2026-10-22T10:00:00.000Z','2026-10-22T10:00:00.000Z')");
  await label('tab-settings').click();
  await text('Backup & restore').dispatchEvent('click');
  await waitForText('Restore from a file');
  await text('Text export (.json)', { exact: true }).last().click();
  await waitForText('text only');
  const jsonUri = (await files()).filter((u) => u.includes('/backups/') && u.endsWith('.json')).pop();
  await page.evaluate((u) => { window.__files.set('file:///cache/r.json', window.__files.get(u)); }, jsonUri);
  raw.exec("DELETE FROM entries WHERE uuid='b2b0000000000000000000000000000a'");

  const restoreBtn = () => page.locator('[role="button"]').filter({ hasText: 'Restore from a file' }).first();
  await page.evaluate(() => { window.__nextPickResult = { name: 'r.json', uri: 'file:///cache/r.json' }; });
  await restoreBtn().click();
  await waitForText('Add to my journal');

  // replace asks for confirmation and does nothing until confirmed
  await text('Replace my journal', { exact: true }).last().click();
  await wait(200);
  await waitForText('Replace everything on this device');
  assert.equal(one("SELECT COUNT(*) AS n FROM entries WHERE uuid='b2b0000000000000000000000000000a'").n, 0);
  await page.locator('[data-testid="dialog-cancel"]').click(); await wait(200); // popup, not a native alert
  assert.equal(await page.locator('[data-testid="dialog-cancel"]').count(), 0, 'popup closed');

  // merge
  await text('Add to my journal', { exact: true }).last().click();
  await waitForText('Restore finished');
  assert.equal(one("SELECT COUNT(*) AS n FROM entries WHERE uuid='b2b0000000000000000000000000000a'").n, 1, 'entry restored');
  assert.ok((await bodyText()).includes('1 entries added'), 'summary shows count');

  // an entry that sits in the trash here comes back when the file has it active
  raw.exec("UPDATE entries SET deleted_at='2026-10-28T10:00:00.000Z' WHERE uuid='b2b0000000000000000000000000000a'");
  await text('Close').last().click();
  await page.evaluate(() => { window.__nextPickResult = { name: 'r.json', uri: 'file:///cache/r.json' }; });
  await restoreBtn().click();
  await waitForText('Add to my journal');
  await text('Add to my journal', { exact: true }).last().click();
  await waitForText('Restore finished');
  assert.equal(one("SELECT deleted_at AS d FROM entries WHERE uuid='b2b0000000000000000000000000000a'").d, null, 'trashed entry restored by merge');

  assert.deepEqual(await errors(), []);
  raw.exec("DELETE FROM entries WHERE uuid='b2b0000000000000000000000000000a'");
  await page.evaluate(() => window.__pressBack()); await wait(250);
  await page.evaluate(() => window.__pressBack()); await wait(250);
  await waitForText('Recent entries');
});

console.log('delete, undo, trash, purge');
await step('keyboard: pages get room below the content while it is open, so a short page can scroll the field clear of it', async () => {
  await label('tab-home').click();
  const pad = () => page.evaluate(() => {
    const f = [...document.querySelectorAll('input')].find((i) => (i.placeholder || '').startsWith('Search'));
    let n = f; // the scroll content wrapper is the nearest ancestor with a bottom padding
    while (n && !(parseFloat(getComputedStyle(n).paddingBottom) > 100)) n = n.parentElement;
    return n ? parseFloat(getComputedStyle(n).paddingBottom) : 0;
  });
  const before = await pad();
  await page.evaluate(() => window.__showKeyboard(320));
  await waitFor(async () => (await pad()) >= before + 320);
  await page.evaluate(() => window.__hideKeyboard());
  await waitFor(async () => (await pad()) === before);
  assert.deepEqual(await errors(), []);
});
await step('Preview: tapping an entry opens a read-only page with Back/Edit/Share, photos and text; Edit goes to the editor and back', async () => {
  await label('tab-home').click();
  await text('Istanbul day').first().click();
  const pv = page.locator('[data-testid="entry-preview"]');
  await pv.waitFor();
  assert.equal(await page.locator('[data-testid="editor-frame"]').count(), 0, 'not the editor');
  const t = await pv.innerText();
  assert.ok(t.includes('Istanbul day') && t.includes('Walked by the water'), t);
  for (const l of ['Back', 'Edit', 'Share']) assert.equal(await pv.locator(`[role="button"][aria-label="${l}"]`).count(), 1, l);
  assert.equal(await pv.locator('[role="button"][aria-label="Delete"]').count(), 0, 'no delete on the preview');
  await waitFor(async () => (await pv.locator('img').count()) >= 1);
  // Share opens a chooser: text / picture / styled PDF
  await pv.locator('[role="button"][aria-label="Share"]').click();
  await page.locator('[data-testid="share-sheet"]').waitFor();
  for (const id of ['share-text', 'share-image', 'share-pdf']) assert.equal(await page.locator(`[data-testid="${id}"]`).count(), 1, id);
  await page.locator('[data-testid="share-text"]').click();
  await waitFor(async () => ((await page.evaluate(() => window.__textShared)) || {}).message?.includes('Istanbul day'));
  assert.equal(await page.locator('[data-testid="share-sheet"]').count(), 0, 'sheet closes');
  // picture of the page
  await pv.locator('[role="button"][aria-label="Share"]').click();
  await page.locator('[data-testid="share-image"]').click();
  await page.locator('[data-testid="image-share"]').click();
  await waitFor(async () => (await page.evaluate(() => window.__shots.length)) === 1);
  await waitFor(async () => (await page.evaluate(() => window.__shared.some((x) => x.options.mimeType === 'image/png'))));
  // styled PDF with a chosen template
  await pv.locator('[role="button"][aria-label="Share"]').click();
  await page.locator('[data-testid="share-pdf"]').click();
  await page.locator('[data-testid="tpl-midnight"]').click();
  await page.locator('[data-testid="pdf-share"]').click();
  await waitFor(async () => (await page.evaluate(() => window.__printed.length)) === 1);
  const printed = await page.evaluate(() => window.__printed[0].html);
  assert.ok(printed.includes('tpl-midnight') && printed.includes('Istanbul day') && printed.includes('Walked by the water'), 'pdf html');
  assert.ok(printed.includes('data:image/jpeg;base64,'), 'photo embedded');
  await waitFor(async () => (await page.evaluate(() => window.__shared.some((x) => x.options.mimeType === 'application/pdf'))));
  await waitFor(async () => (await page.locator('[data-testid="share-sheet"]').count()) === 0);
  // file names stay ASCII so Android's share provider accepts them
  const sharedPdf = await page.evaluate(() => window.__shared.filter((x) => x.options.mimeType === 'application/pdf').pop().uri);
  assert.match(sharedPdf, /^[\x21-\x7e]+$/, sharedPdf);
  // save a copy to a folder instead of sharing: picture and PDF
  await pv.locator('[role="button"][aria-label="Share"]').click();
  await page.locator('[data-testid="share-image"]').click();
  await page.locator('[data-testid="image-save"]').click();
  await waitFor(async () => ((await page.evaluate(() => window.__safCreated)) || []).some((u) => u.endsWith('.png')));
  await waitForText('Saved to the folder you chose.');
  await page.locator('[data-testid="dialog-ok"]').click();
  await pv.locator('[role="button"][aria-label="Share"]').click();
  await page.locator('[data-testid="share-pdf"]').click();
  await page.locator('[data-testid="pdf-save"]').click();
  await waitFor(async () => ((await page.evaluate(() => window.__safCreated)) || []).some((u) => u.endsWith('.pdf')));
  await waitForText('Saved to the folder you chose.');
  await page.locator('[data-testid="dialog-ok"]').click();
  // Edit -> editor; Done -> back on the preview
  await editFromPreview();
  await page.waitForSelector('[data-testid="editor-frame"]');
  await text('Done').click();
  await pv.waitFor();
  // Back closes
  await pv.locator('[role="button"][aria-label="Back"]').click();
  await waitFor(async () => (await page.locator('[data-testid="entry-preview"]').count()) === 0);
  assert.deepEqual(await errors(), []);
});
await step('Plan (free): PDF sharing and editor fonts ask for Premium, text/picture sharing stays free', async () => {
  const later = () => page.locator('[data-testid="premium-later"]').click();
  await label('tab-settings').click();
  await text('Free', { exact: true }).first().click();
  await waitFor(() => (one("SELECT value FROM app_settings WHERE key='premium'") || {}).value === 'false');
  await label('tab-home').click();
  await text('Istanbul day').first().click();
  const pv = page.locator('[data-testid="entry-preview"]');
  await pv.waitFor();
  await pv.locator('[role="button"][aria-label="Share"]').click();
  await page.locator('[data-testid="share-text"]').waitFor();
  await page.locator('[data-testid="share-pdf"]').click();
  await waitForText('Sharing an entry as a beautifully styled PDF is part of Premium');
  assert.equal(await page.locator('[data-testid="tpl-midnight"]').count(), 0, 'templates stay hidden');
  await later();
  await page.locator('[data-testid="share-image"]').click(); // picture sharing is free
  await page.locator('[data-testid="image-share"]').waitFor();
  await page.locator('[data-testid="share-sheet"] [aria-label="Close"]').dispatchEvent('click'); // the stub icon has no size
  // fonts
  await editFromPreview();
  await page.waitForSelector('[data-testid="editor-frame"]');
  await page.locator('[data-testid="fmt-font"]').click();
  await waitForText('Choosing fonts for your writing is part of Premium');
  await later();
  await text('Done').click(); await closePreview();
  // back to Premium for the rest of the run
  await label('tab-settings').click();
  await text('Premium', { exact: true }).first().click();
  await waitFor(() => (one("SELECT value FROM app_settings WHERE key='premium'") || {}).value === 'true');
  await label('tab-home').click();
  await waitForText('Recent entries');
  assert.deepEqual(await errors(), []);
});
await step('delete → Undo restores; Alert is shown for confirmation', async () => {
  await label('tab-home').click();
  await page.locator('[role="button"]').filter({ hasText: 'Istanbul day' }).first().click().catch(() => {});
  await text('Istanbul day').first().click();
  await editFromPreview();
  await text('Delete', { exact: true }).last().click();
  await waitForText('Delete', 3000);
  await page.locator('[data-testid="dialog-destructive"]').click(); await wait(600);
  await waitFor(() => one("SELECT deleted_at FROM entries WHERE title='Istanbul day'").deleted_at);
  await waitForText('Entry deleted');
  await text('Undo').click();
  await waitFor(() => one("SELECT deleted_at FROM entries WHERE title='Istanbul day'").deleted_at === null);
});
await step('Trash screen lists a deleted entry; restore works; purge removes files', async () => {
  // delete again via the editor
  await text('Istanbul day').first().click();
  await editFromPreview();
  await text('Delete', { exact: true }).last().click();
  await page.locator('[data-testid="dialog-destructive"]').click(); await wait(150);
  await waitFor(() => one("SELECT deleted_at FROM entries WHERE title='Istanbul day'").deleted_at);
  await label('tab-settings').click();
  await waitForText('1 in trash');
  await text('Trash').click();
  await waitForText('Istanbul day');
  assert.ok((await bodyText()).includes('Walked by the water'));
  // photos are kept while in trash
  assert.equal(q('SELECT * FROM attachments').length, 1);
  const att = one('SELECT * FROM attachments');

  await text('Delete forever').click();
  await page.locator('[data-testid="dialog-destructive"]').click(); await wait(150);
  await waitFor(() => !one('SELECT * FROM entries'));
  assert.equal(q('SELECT * FROM attachments').length, 0);
  assert.equal(q('SELECT * FROM locations').length, 0);
  assert.equal(q('SELECT * FROM entry_emotions').length, 0);
  const f = await files();
  assert.ok(!f.includes('file:///docs/attachments/' + att.file_name), 'photo file deleted');
  assert.ok(!f.includes('file:///docs/attachments/' + att.thumb_name), 'thumb file deleted');
  await waitForText('Trash is empty');
});

console.log('stories');
await step('Home stories: On this day / Last month / Last year circles, timed auto-advance, tap, Open entry; locked for free', async () => {
  const d = new Date(); const y = d.getFullYear(); const mm = String(d.getMonth() + 1).padStart(2, '0'); const dd = String(d.getDate()).padStart(2, '0');
  if (`${mm}-${dd}` === '02-29') return;
  const pm = new Date(y, d.getMonth() - 1, 15); const pmKey = `${pm.getFullYear()}-${String(pm.getMonth() + 1).padStart(2, '0')}-15`;
  const ins = (u, title, date, fav) => `('${u}','${title}','body of ${title}','${date}',${fav},0,'t','t')`;
  raw.exec(`INSERT INTO entries (uuid,title,body,journal_date,favorite,pinned,created_at,updated_at) VALUES
    ${ins('0a0000000000000000000000000000a1', 'memory one year', `${y - 1}-${mm}-${dd}`, 0)},
    ${ins('0a0000000000000000000000000000a2', 'memory two years', `${y - 2}-${mm}-${dd}`, 0)},
    ${ins('0a0000000000000000000000000000a3', 'best of last month', pmKey, 1)},
    ${ins('0a0000000000000000000000000000a4', 'best of last year', `${y - 1}-06-15`, 1)}`);
  await label('tab-home').click();
  await waitForText('Recent entries');
  // a saved entry makes the app reload its list (and picks up the rows added above)
  await label('New entry').click();
  await page.getByPlaceholder('A title for today (optional)').fill('zz refresh');
  await waitFor(() => one("SELECT id FROM entries WHERE title='zz refresh'"));
  await text('Done', { exact: true }).click();
  const circle = (k) => page.locator(`[data-testid="story-${k}"]`);
  await circle('today').waitFor(); await circle('lastMonth').waitFor(); await circle('lastYear').waitFor();
  assert.equal(await page.locator('[data-testid="on-this-day"]').count(), 0, 'no old card');
  await page.evaluate(() => { window.__STORY_MS = 500; });
  // On this day: 2 slides, nearest year first, advances on its own, closes after the last
  await circle('today').dispatchEvent('click');
  await page.locator('[data-testid="story-viewer"]').waitFor();
  await waitForText('A year ago'); await waitForText('memory one year');
  await waitForText('2 years ago'); await waitForText('memory two years');
  await waitFor(async () => (await page.locator('[data-testid="story-viewer"]').count()) === 0);
  // tap right goes forward and the last tap closes; Open entry shows the preview
  await page.evaluate(() => { window.__STORY_MS = 60000; });
  await circle('lastMonth').dispatchEvent('click');
  await waitForText('best of last month');
  await page.locator('[data-testid="story-next"]').dispatchEvent('click');
  await waitFor(async () => (await page.locator('[data-testid="story-viewer"]').count()) === 0);
  await circle('lastYear').dispatchEvent('click');
  await waitForText('best of last year');
  await text('Open entry', { exact: true }).dispatchEvent('click');
  await page.locator('[data-testid="entry-preview"]').waitFor();
  await closePreview();
  // free plan: circles are locked and open the Premium popup
  await label('tab-settings').click();
  await text('Free', { exact: true }).first().click();
  await waitFor(() => (one("SELECT value FROM app_settings WHERE key='premium'") || {}).value === 'false');
  await label('tab-home').click();
  await circle('today').dispatchEvent('click');
  await waitForText('Stories on Home are part of Premium');
  assert.equal(await page.locator('[data-testid="story-viewer"]').count(), 0, 'no player for free users');
  await page.locator('[data-testid="premium-later"]').click();
  await label('tab-settings').click();
  await text('Premium', { exact: true }).first().click();
  await waitFor(() => (one("SELECT value FROM app_settings WHERE key='premium'") || {}).value === 'true');
  await label('tab-home').click();
  raw.exec("DELETE FROM entries WHERE uuid LIKE '0a00000000000000000000000000%' OR title='zz refresh'");
});

console.log('rich editor');
await step('rich editor: bold/italic/heading/list, mixed RTL+LTR paragraphs, saved as sanitised HTML, reopen restores', async () => {
  raw.exec("INSERT INTO entries (uuid,title,body,journal_date,favorite,pinned,created_at,updated_at) VALUES ('eeeeeeeeeeeeeeeeeeeeeeeeeeeeee77','legacy','line one\nline <two> & three','2026-10-20',0,0,'t','t')");
  await label('tab-home').click();
  await waitForText('Recent entries');
  await label('New entry').click();
  await page.getByPlaceholder('A title for today (optional)').fill('rich test');
  const fr = await editorFrame();
  await fr.click('#ed');
  await page.keyboard.type('Plain then bold');
  // select the last word "bold" and make it bold through the toolbar
  await page.keyboard.down('Shift');
  for (let i = 0; i < 4; i++) await page.keyboard.press('ArrowLeft');
  await page.keyboard.up('Shift');
  await page.locator('[data-testid="fmt-bold"]').click();
  await wait(250);
  assert.match(await bodyHtmlInEditor(), /<(strong|b)>bold<\/(strong|b)>/);
  assert.equal(await page.locator('[data-testid="fmt-bold"]').getAttribute('aria-selected') ?? 'x', 'true');
  // next paragraph: Persian, then a heading and a list
  await fr.click('#ed');
  await page.keyboard.press('Control+End');
  await page.locator('[data-testid="fmt-bold"]').click(); // typing continues in the format; toggle it off
  await page.keyboard.press('Enter');
  await page.keyboard.type('سلام دنیا');
  await page.keyboard.press('Enter');
  await page.keyboard.type('Heading text');
  await page.locator('[data-testid="fmt-h1"]').click();
  await page.keyboard.press('Enter');
  await page.keyboard.type('item one');
  await page.locator('[data-testid="fmt-ul"]').click();
  await page.keyboard.press('Enter');
  await page.keyboard.type('item two');
  await wait(1500);
  const row = one("SELECT * FROM entries WHERE title='rich test'");
  assert.ok(row, 'entry saved');
  assert.equal(row.content_format_version, 2);
  assert.match(row.body_html, /<strong>bold<\/strong>/);
  assert.match(row.body_html, /<h1[^>]*>Heading text<\/h1>/);
  assert.match(row.body_html, /<ul><li>item one<\/li><li>item two<\/li><\/ul>/);
  assert.ok(row.body_html.includes('سلام دنیا'));
  assert.equal(row.body, 'Plain then bold\nسلام دنیا\nHeading text\n• item one\n• item two');
  assert.ok(!/<script|onerror|style=/.test(row.body_html));
  // every paragraph lays out in its own direction: Persian hugs the right edge, English the left (LTR app)
  const geo = await fr.evaluate(() => {
    const ed = document.getElementById('ed'); const box = ed.getBoundingClientRect();
    const rectOf = (el) => { const r = document.createRange(); r.selectNodeContents(el); return r.getBoundingClientRect(); };
    const [en, fa] = [ed.children[0], ed.children[1]];
    return { boxL: box.left, boxR: box.right, enL: rectOf(en).left, faR: rectOf(fa).right };
  });
  assert.ok(Math.abs(geo.enL - geo.boxL) < 3, 'English starts at the left: ' + JSON.stringify(geo));
  assert.ok(Math.abs(geo.faR - geo.boxR) < 3, 'Persian starts at the right: ' + JSON.stringify(geo));
  // undo works through the toolbar
  await page.locator('[data-testid="fmt-undo"]').click();
  await wait(300);
  await text('Done').click();
  await wait(400);
  // reopen: formatting is restored
  await waitForText('rich test');
  await text('rich test').first().click();
  await editFromPreview();
  const html2 = await bodyHtmlInEditor();
  assert.ok(html2.includes('<strong>bold</strong>') && html2.includes('<h1'), html2);
  await text('Done').click(); await closePreview();
  await wait(300);
  raw.exec("DELETE FROM entries WHERE title='rich test'");
  assert.deepEqual(await errors(), []);
});
await step('rich editor: lists toggle off, switch type without nesting, Backspace/Enter leave the list; direction; colour; undo is grouped', async () => {
  await label('tab-home').click();
  await label('New entry').click();
  const fr = await editorFrame();
  const html = () => fr.evaluate(() => document.getElementById('ed').innerHTML);
  await fr.click('#ed');
  await page.keyboard.type('alpha');
  await page.locator('[data-testid="fmt-ul"]').click();
  assert.equal(await html(), '<ul><li>alpha</li></ul>');
  await page.locator('[data-testid="fmt-ul"]').click(); // second tap removes it
  assert.equal(await html(), '<p>alpha</p>');
  await page.locator('[data-testid="fmt-ul"]').click();
  await page.locator('[data-testid="fmt-ol"]').click(); // switches type, never nests
  assert.equal(await html(), '<ol><li>alpha</li></ol>');
  await page.locator('[data-testid="fmt-ol"]').click();
  await page.locator('[data-testid="fmt-ul"]').click();
  await page.keyboard.press('End'); await page.keyboard.press('Enter'); await page.keyboard.type('beta');
  await page.keyboard.press('Home'); await page.keyboard.press('Backspace'); // leaves the list
  assert.equal(await html(), '<ul><li>alpha</li></ul><p>beta</p>');
  await page.keyboard.press('Control+End'); await page.keyboard.press('Enter');
  await page.keyboard.type('x'); await page.keyboard.press('Backspace');
  await page.locator('[data-testid="fmt-ul"]').click(); await page.keyboard.press('Enter'); // Enter on an empty item leaves
  assert.ok(!(await html()).includes('<li><br>'), await html());

  // direction: forced RTL, then back to automatic
  await fr.evaluate(() => { document.getElementById('ed').innerHTML = '<p>hello</p>'; });
  await fr.click('#ed p');
  await page.locator('[data-testid="fmt-rtl"]').click();
  assert.equal(await html(), '<p dir="rtl">hello</p>');
  const right = await fr.evaluate(() => { const ed = document.getElementById('ed'); const r = document.createRange(); r.selectNodeContents(ed.firstChild); return Math.abs(r.getBoundingClientRect().right - ed.getBoundingClientRect().right) < 3; });
  assert.ok(right, 'forced RTL hugs the right edge even for Latin text');
  await page.locator('[data-testid="fmt-rtl"]').click();
  assert.equal(await html(), '<p>hello</p>');

  // colour
  await fr.evaluate(() => { const r = document.createRange(); r.selectNodeContents(document.querySelector('#ed p')); getSelection().removeAllRanges(); getSelection().addRange(r); });
  await page.locator('[data-testid="fmt-color"]').click();
  await page.locator('[data-testid="color-d6453d"]').click();
  await wait(300);
  assert.match(await html(), /color: rgb\(214, 69, 61\)/);
  await wait(1200);
  assert.match(one("SELECT body_html FROM entries WHERE body LIKE '%hello%' ORDER BY id DESC LIMIT 1").body_html, /<span style="color:#d6453d">hello<\/span>/);

  // undo removes a whole burst of typing, not one letter
  await fr.evaluate(() => { document.getElementById('ed').innerHTML = '<p><br></p>'; });
  await fr.click('#ed');
  await page.keyboard.type('one two three');
  await wait(900);
  await page.keyboard.type(' four five six');
  await wait(900);
  await page.locator('[data-testid="fmt-undo"]').click();
  assert.equal(await fr.evaluate(() => document.getElementById('ed').innerText.trim()), 'one two three');
  await page.locator('[data-testid="fmt-redo"]').click();
  assert.equal(await fr.evaluate(() => document.getElementById('ed').innerText.trim()), 'one two three four five six');
  await text('Done').click();
  await wait(400);
  raw.exec("DELETE FROM entries WHERE body LIKE '%one two three%' OR body LIKE '%hello%' OR body LIKE '%alpha%'");
  assert.deepEqual(await errors(), []);
});
await step('rich editor: font and highlight from the toolbar are saved and survive reopening', async () => {
  await label('tab-home').click();
  await label('New entry').click();
  await page.getByPlaceholder('A title for today (optional)').fill('fonts test');
  const fr = await editorFrame();
  await fr.click('#ed');
  await page.keyboard.type('styled words');
  await page.keyboard.press('Control+A');
  await page.locator('[data-testid="fmt-font"]').click();
  await page.locator('[data-testid="font-naskh"]').click();
  await page.locator('[data-testid="fmt-highlight"]').click();
  await page.locator('[data-testid="highlight-0"]').click();
  await wait(1500);
  const row = one("SELECT * FROM entries WHERE title='fonts test'");
  assert.match(row.body_html, /font-family:'Noto Naskh Arabic',serif/);
  assert.match(row.body_html, /background-color:rgba\(255,213,79,0\.45\)/);
  assert.equal(row.body, 'styled words');
  // the toolbar reflects the formatting at the caret
  await fr.click('#ed');
  await wait(300);
  assert.equal(await page.locator('[data-testid="fmt-font"]').getAttribute('aria-selected'), 'true');
  // reset both
  await page.keyboard.press('Control+A');
  await page.locator('[data-testid="fmt-font"]').click();
  await page.locator('[data-testid="font-default"]').click();
  await page.locator('[data-testid="fmt-highlight"]').click();
  await page.locator('[data-testid="highlight-none"]').click();
  await wait(1500);
  const clean = one("SELECT body_html FROM entries WHERE title='fonts test'").body_html;
  assert.ok(!/font-family|background/.test(clean), clean);
  await text('Done').click();
  await wait(300);
  raw.exec("DELETE FROM entries WHERE title='fonts test'");
  assert.deepEqual(await errors(), []);
});
await step('rich editor: legacy plain-text entry opens as paragraphs and stays plain until edited', async () => {
  await label('tab-home').click();
  await waitForText('legacy');
  await text('legacy').first().click();
  await editFromPreview();
  const html = await bodyHtmlInEditor();
  assert.ok(html.includes('line one') && html.includes('&lt;two&gt; &amp; three'), html);
  await text('Done').click(); await closePreview();
  await wait(500);
  const row = one("SELECT * FROM entries WHERE title='legacy'");
  assert.equal(row.content_format_version, 1, 'opening without editing does not convert');
  assert.equal(row.body_html, null);
  raw.exec("DELETE FROM entries WHERE title='legacy'");
});
console.log('tablet');
await step('tablet landscape: dock does not overlap content; one Settings button', async () => {
  await page.setViewportSize({ width: 1180, height: 800 });
  await wait(600);
  await label('tab-home').click();
  await waitForText('Recent entries');
  const r = await page.evaluate(() => {
    const dock = document.querySelector('[data-testid="tab-home"]').closest('[style*="position: absolute"]').getBoundingClientRect();
    const h = [...document.querySelectorAll('span')].find((e) => e.textContent === 'Recent entries' || e.textContent === 'Kitty Journal' && false) ; if (!h) return { missing: document.body.innerText.slice(0, 200) }; const hr = h.getBoundingClientRect();
    const settings = document.querySelectorAll('[aria-label="Settings"]').length;
    return { dockRight: dock.right, textLeft: hr.left, settings, dockTop: dock.top };
  });
  await page.screenshot({ path: '/tmp/tablet.png' });
  await page.setViewportSize({ width: 412, height: 860 });
  await wait(400);
  assert.ok(r.textLeft >= r.dockRight, 'content starts right of the dock: ' + JSON.stringify(r));
  assert.equal(r.settings, 1, 'only one Settings control: ' + JSON.stringify(r));
});
console.log('tags manager, back button, settings persistence');
await step('tag manager: rename and merge, delete keeps entries', async () => {
  // two entries with tags
  raw.exec(`INSERT INTO entries (uuid,title,body,journal_date,favorite,pinned,created_at,updated_at) VALUES ('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa1','one','x','2026-10-01',0,0,'t','t'),('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa2','two','y','2026-10-02',0,0,'t','t');
    INSERT INTO tags (name,name_key,created_at,updated_at) VALUES ('Work','work','t','t'),('Jobs','jobs','t','t');
    INSERT INTO entry_tags SELECT e.id, t.id FROM entries e, tags t WHERE (e.title='one' AND t.name='Work') OR (e.title='two' AND t.name='Jobs');`);
  await page.evaluate(() => window.__pressBack()); // sub-screen -> settings
  await wait(250); // let React re-register the Back listener, as a human tap would
  await page.evaluate(() => window.__pressBack()); // settings closed
  await wait(250);
  await label('tab-settings').click();
  await waitForText('Manage tags');
  // the floating dock overlaps the last row in this un-scrolled harness; click the row directly
  await text('Manage tags').dispatchEvent('click');
  await waitForText('#Work');
  await label('Rename: Jobs').click();
  const input = page.getByLabel('Rename tag').last();
  await input.fill('work');
  await text('Rename', { exact: true }).last().click();
  await waitFor(() => q("SELECT * FROM tags WHERE name_key IN ('work','jobs')").length === 1);
  assert.equal(one('SELECT COUNT(*) AS n FROM entry_tags').n, 2);
  assert.equal(q('SELECT * FROM entries').length, 2);
  await label('Delete tag: work').click();
  await page.locator('[data-testid="dialog-destructive"]').click(); await wait(150);
  await waitFor(() => q("SELECT * FROM tags WHERE name_key='work'").length === 0);
  assert.equal(q('SELECT * FROM entries').length, 2);
});
await step('Android Back: sub-screen → settings → previous tab → Home → exit', async () => {
  assert.equal(await page.evaluate(() => window.__pressBack()), true); // tags -> settings
  await waitForText('Language');
  await wait(250);
  assert.equal(await page.evaluate(() => window.__pressBack()), true); // settings -> home tab shown
  await wait(250);
  await label('tab-calendar').click();
  await waitForText('Selected date');
  await wait(250);
  assert.equal(await page.evaluate(() => window.__pressBack()), true); // calendar -> home
  await waitForText('Recent entries');
  await wait(250);
  assert.equal(await page.evaluate(() => window.__pressBack()), false); // lets the OS exit
});
await step('Insights mood distribution counts a mood picked in the editor; calendar has no inline + button', async () => {
  await label('tab-home').click();
  await label('tab-insights').click();
  await waitForText('Mood distribution');
  assert.equal(await page.locator('[aria-label="New entry"]').count(), 0, 'no floating add button on Insights');
  assert.ok((await bodyText()).includes(NO_MOOD), 'precondition: no mood data yet');
  await label('tab-home').click();
  await label('New entry').click();
  await page.getByPlaceholder('A title for today (optional)').fill('mood test');
  await waitFor(() => one("SELECT * FROM entries WHERE title='mood test'"));
  await label('Good').last().click();
  await waitFor(() => one("SELECT mood FROM entries WHERE title='mood test'").mood === 'good');
  await text('Done').click();
  await label('tab-insights').click();
  await waitFor(async () => !(await bodyText()).includes(NO_MOOD));
  await label('tab-calendar').click();
  assert.equal(await page.locator('[aria-label="New entry"]').count(), 1, 'only the floating add button remains');
});
console.log('C3: insights');
await step('Insights (C3): range switch, writing days, words, monthly/weekday charts, tags, mood note', async () => {
  await label('tab-insights').click();
  await waitForText('Words written');
  const body = await bodyText();
  for (const h of ['Entries by month', 'Writing by weekday', 'Mood distribution', 'Words per entry']) assert.ok(body.includes(h), h);
  assert.ok(body.includes('Days without a mood are left out'), 'honest-data note');
  // default range is 30 days; 7 days narrows "of N days" to 7
  assert.ok(/of 30 days/.test(body), 'default 30-day range');
  await text('7 days', { exact: true }).first().click();
  await waitFor(async () => /of 7 days/.test(await bodyText()));
  await text('1 year', { exact: true }).first().click();
  await waitFor(async () => /of 365 days/.test(await bodyText()));
  await text('90 days', { exact: true }).first().click();
  await waitFor(async () => /of 90 days/.test(await bodyText()));
  await text('All time', { exact: true }).first().click();
  await waitFor(async () => !/of 7 days|of 365 days|of 90 days/.test(await bodyText()));
  assert.ok((await bodyText()).includes('Weekly mood'), 'weekly mood chart when moods were recorded');
  assert.deepEqual(await errors(), []);
  await label('tab-home').click();
  await waitForText('Recent entries');
});
await step('Restore (B2b): replace makes a safety backup first and swaps the journal', async () => {
  raw.exec("UPDATE entries SET created_at='2026-10-01T10:00:00.000Z' WHERE length(created_at)<20; UPDATE entries SET updated_at='2026-10-01T10:00:00.000Z' WHERE length(updated_at)<20");
  raw.exec("INSERT OR IGNORE INTO entries (uuid,title,body,journal_date,favorite,pinned,created_at,updated_at) VALUES ('b2b0000000000000000000000000000a','restore me','text','2026-10-22',0,0,'2026-10-22T10:00:00.000Z','2026-10-22T10:00:00.000Z')");
  await label('tab-settings').click();
  await text('Backup & restore').dispatchEvent('click');
  await waitForText('Restore from a file');
  await text('Text export (.json)', { exact: true }).last().click();
  await waitForText('text only');
  const jsonUri = (await files()).filter((u) => u.includes('/backups/') && u.endsWith('.json')).pop();
  await page.evaluate((u) => { window.__files.set('file:///cache/r.json', window.__files.get(u)); }, jsonUri);
  const restoreBtn = () => page.locator('[role="button"]').filter({ hasText: 'Restore from a file' }).first();

  // replace: after confirming, a safety backup exists and the journal equals the file
  raw.exec("INSERT INTO entries (uuid,title,body,journal_date,favorite,pinned,created_at,updated_at) VALUES ('b2b0000000000000000000000000000b','local only','text','2026-10-23',0,0,'2026-10-23T10:00:00.000Z','2026-10-23T10:00:00.000Z')");
  await page.evaluate(() => { window.__nextPickResult = { name: 'r.json', uri: 'file:///cache/r.json' }; });
  await restoreBtn().click();
  await waitForText('Replace my journal');
  await text('Replace my journal', { exact: true }).last().click();
  await wait(200);
  await page.locator('[data-testid="dialog-destructive"]').click(); await wait(150);
  await waitFor(async () => (await bodyText()).includes('Safety backup saved'));
  assert.ok((await files()).some((u) => u.includes('kitty-journal-safety') && u.endsWith('.zip')), 'safety backup written');
  assert.equal(one("SELECT COUNT(*) AS n FROM entries WHERE uuid='b2b0000000000000000000000000000b'").n, 0, 'local-only entry replaced');
  assert.equal(one("SELECT COUNT(*) AS n FROM entries WHERE uuid='b2b0000000000000000000000000000a'").n, 1, 'file entry present');
  assert.deepEqual(await errors(), []);
  await page.evaluate(() => window.__pressBack()); await wait(250);
  await page.evaluate(() => window.__pressBack()); await wait(250);
  await label('tab-home').click();
  await waitForText('Recent entries');
});

console.log('B3: storage');
await step('Storage (B3): usage shown; unused files cleaned; broken photo records found and removed; backup copies deleted', async () => {
  await label('tab-settings').click();
  await text('Storage', { exact: true }).first().click();
  await waitForText('Free space on this device');
  // an orphan file nothing references
  await page.evaluate(() => window.__files.set('file:///docs/attachments/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.jpg', 'QUJD'));
  await page.locator('[role="button"]').filter({ hasText: 'Clean up unused files' }).first().click();
  await waitForText('1 unused files removed');
  assert.ok(!(await files()).some((u) => u.endsWith('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.jpg')), 'orphan removed');
  // a photo row whose file is gone
  const entry = one('SELECT id FROM entries LIMIT 1');
  raw.exec(`INSERT INTO attachments (uuid, entry_id, file_name, thumb_name, created_at) VALUES ('b3test0000000000000000000000000z', ${entry.id}, 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb.jpg', 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb_t.jpg', '2026-10-01T10:00:00.000Z')`);
  await page.locator('[role="button"]').filter({ hasText: 'Check photo files' }).first().click();
  await waitForText('1 photos have a missing file');
  await text('Remove broken photo entries', { exact: true }).last().click();
  await wait(200);
  await page.locator('[data-testid="dialog-destructive"]').click(); await wait(150);
  await waitForText('All photo files are present');
  assert.equal(one("SELECT COUNT(*) AS n FROM attachments WHERE file_name LIKE 'bbbb%'").n, 0, 'broken record removed');
  // backup copies kept in the app
  assert.ok((await files()).some((u) => u.includes('/backups/')), 'backup files exist before');
  await page.locator('[role="button"]').filter({ hasText: 'Delete backup copies kept in the app' }).first().click();
  await wait(200);
  await page.locator('[data-testid="dialog-destructive"]').click(); await wait(150);
  await waitForText('backup files deleted');
  assert.ok(!(await files()).some((u) => u.includes('/backups/')), 'backup files removed');
  assert.deepEqual(await errors(), []);
  await page.evaluate(() => window.__pressBack()); await wait(250);
  await page.evaluate(() => window.__pressBack()); await wait(250);
  await label('tab-home').click();
  await waitForText('Recent entries');
});

console.log('B4: reminders');
await step('Reminders (B4): permission, schedule per weekday, no duplicates on edit, off cancels, tap opens a new entry', async () => {
  raw.exec("DELETE FROM app_settings WHERE key='reminder'"); // the onboarding step above left one on
  await page.evaluate(() => window.__scheduled.splice(0));
  await label('tab-settings').click();
  await text('Writing reminder', { exact: true }).first().click();
  await waitForText('Remind me to write');
  const toggle = page.locator('input[type="checkbox"][aria-label="Remind me to write"]');
  const dayLabels = await page.locator('[role="button"][aria-label]').evaluateAll((els) => els.map((e) => e.getAttribute('aria-label')).filter((l) => /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun)$/.test(l)));
  assert.deepEqual(dayLabels, ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], 'week starts on Monday');
  const scheduled = () => page.evaluate(() => window.__scheduled.length);

  // permission denied: stays off, explains why, schedules nothing
  await page.evaluate(() => { window.__notifPerm = 'denied'; });
  await toggle.click();
  await waitForText('Notifications are turned off for Kitty Journal');
  assert.equal(await scheduled(), 0);
  assert.equal(await toggle.isChecked(), false);

  // granted: one weekly notification per selected day, in 8:00 PM by default
  await page.evaluate(() => { window.__notifPerm = 'granted'; });
  await toggle.click();
  await waitForText('Reminder set');
  assert.equal(await scheduled(), 7);
  const first = await page.evaluate(() => window.__scheduled[0].trigger);
  assert.equal(first.hour, 20);
  assert.equal(first.minute, 0);
  assert.equal((await one("SELECT value FROM app_settings WHERE key='reminder'")).value.includes('"enabled":true'), true);

  // editing re-plans from scratch: still 7, never 14
  await page.locator('[role="button"][aria-label="Minute +"]').first().click();
  await wait(300);
  assert.equal(await scheduled(), 7);
  assert.equal((await page.evaluate(() => window.__scheduled[0].trigger)).minute, 5);
  await page.locator('[role="button"][aria-label]').filter({ hasText: /^Sun$/ }).first().click();
  await wait(300);
  assert.equal(await scheduled(), 6);

  // off cancels everything
  await toggle.click();
  await waitForText('Reminder turned off');
  assert.equal(await scheduled(), 0);
  assert.deepEqual(await errors(), []);

  // tapping a reminder opens the new-entry editor
  await page.evaluate(() => window.__pressBack()); await wait(250);
  await page.evaluate(() => window.__pressBack()); await wait(250);
  await page.evaluate(() => window.__tapNotification());
  await page.waitForSelector('[data-testid="editor-frame"]');
  await text('Done').click();
  await label('tab-home').click();
  await waitForText('Recent entries');
});

console.log('C1: app lock');
await step('App lock (C1): set PIN, lock on return, wrong/right PIN, biometric, change PIN, turn off', async () => {
  const pad = async (pin) => {
    for (const d of pin) await page.locator(`[role="button"][aria-label="${d}"]`).first().click();
    await page.locator('[role="button"][aria-label="Done"]').first().click();
  };
  const background = async () => { await page.evaluate(() => window.__setAppState('background')); await wait(100); await page.evaluate(() => window.__setAppState('active')); await wait(200); };
  await label('tab-settings').click();
  await page.setViewportSize({ width: 412, height: 1700 }); await wait(400); // harness root grows with content; tall viewport keeps every row above the dock
  await text('App lock', { exact: true }).first().click();
  await page.setViewportSize({ width: 412, height: 860 }); await wait(300);
  await waitForText('Turn on app lock');
  await text('Turn on app lock', { exact: true }).last().click();
  await waitForText('Choose a PIN');
  await pad('1234');
  await waitForText('Repeat the PIN');
  await pad('9999');                       // mismatch -> starts over
  await waitForText('The two PINs do not match.');
  await pad('1234');
  await waitForText('Repeat the PIN');
  await pad('1234');
  await waitForText('App lock is on');
  assert.ok(await page.evaluate(() => window.__secure.has('kj.pin.v1')), 'PIN record stored in the secure store');
  assert.ok(!(await page.evaluate(() => JSON.stringify([...window.__secure.values()]))).includes('1234'), 'PIN itself is never stored');
  assert.equal(JSON.parse(one("SELECT value FROM app_settings WHERE key='lockEnabled'").value), true);

  // leaving the app locks it, and nothing of the journal is rendered
  await background();
  await waitForText('Kitty Journal is locked');
  assert.ok(!(await bodyText()).includes('Recent entries') && !(await bodyText()).includes('App lock is on'), 'journal hidden while locked');
  await pad('0000');
  await waitForText('Wrong PIN.');
  await pad('1234');
  await waitForText('Turn off app lock');
  assert.ok(!(await bodyText()).includes('Kitty Journal is locked'));

  // fingerprint unlocks without a PIN
  await page.locator('input[type="checkbox"][aria-label="Use fingerprint / face"]').click();
  await wait(300);
  await page.evaluate(() => { window.__bioCalls = 0; });
  await background();
  await waitFor(async () => (await page.evaluate(() => window.__bioCalls)) >= 1);
  await waitForText('Turn off app lock');
  assert.ok(!(await bodyText()).includes('Kitty Journal is locked'), 'biometric unlocked');
  await page.locator('input[type="checkbox"][aria-label="Use fingerprint / face"]').click();
  await wait(300);

  // change PIN
  await text('Change PIN', { exact: true }).last().click();
  await waitForText('Enter your current PIN');
  await pad('1234');
  await waitForText('Choose a new PIN');
  await pad('4321');
  await waitForText('Repeat the PIN');
  await pad('4321');
  await waitForText('PIN changed');
  await background();
  await waitForText('Kitty Journal is locked');
  await pad('1234');
  await waitForText('Wrong PIN.');
  await pad('4321');
  await waitForText('Turn off app lock');

  // turn off
  await text('Turn off app lock', { exact: true }).last().click();
  await waitForText('Enter your PIN');
  await pad('4321');
  await waitForText('App lock is off');
  assert.ok(!(await page.evaluate(() => window.__secure.has('kj.pin.v1'))), 'PIN record removed');
  await background();
  assert.ok(!(await bodyText()).includes('Kitty Journal is locked'), 'no lock when off');
  assert.deepEqual(await errors(), []);
  await page.evaluate(() => window.__pressBack()); await wait(250);
  await page.evaluate(() => window.__pressBack()); await wait(250);
  await label('tab-home').click();
  await waitForText('Recent entries');
});

await step('colour theme can be chosen and persists', async () => {
  await label('tab-settings').click();
  assert.equal(await page.locator('[data-testid="theme-rose"]').count(), 0, 'themes are not crammed into Settings');
  await text('Appearance', { exact: true }).first().click();
  await waitForText('Color theme');
  const before = await page.evaluate(() => getComputedStyle(document.body).backgroundColor + '|' + (document.querySelector('[data-testid="theme-rose"] > div')||{style:{}}).style.backgroundColor);
  await page.locator('[data-testid="theme-rose"]').click();
  await waitFor(() => (one("SELECT value FROM app_settings WHERE key='theme'") || {}).value === '"rose"');
  const after = await page.evaluate(() => document.querySelector('[data-testid="theme-rose"] > div').getAttribute('style') || '');
  assert.ok(/border-width: 3px|border: 3px/.test(after) || after !== before, 'selected swatch styled');
  await page.locator('[data-testid="theme-sage"]').click();
  await waitFor(() => (one("SELECT value FROM app_settings WHERE key='theme'") || {}).value === '"sage"');
  assert.deepEqual(await errors(), []);
  await page.evaluate(() => window.__pressBack()); await wait(250);
  await page.evaluate(() => window.__pressBack()); await wait(250);
  await label('tab-home').click();
  await waitForText('Recent entries');
});

await step('settings persist to the database and Persian switches layout/labels', async () => {
  await label('tab-settings').click();
  await text('فارسی').click();
  await waitFor(() => (one("SELECT value FROM app_settings WHERE key='language'") || {}).value === '"fa"');
  await waitForText('تنظیمات');
  await text('Dark').click().catch(() => {});
  assert.deepEqual(await errors(), []);
});
await step('Persian RTL: dock order/pill and text alignment', async () => {
  await label('tab-home').click();
  await waitForText('Kitty Journal');
  const x = async (id) => (await page.locator(`[data-testid="${id}"]`).boundingBox()).x;
  assert.ok((await x('tab-home')) > (await x('tab-insights')), 'Home is the right-most tab in RTL');
  // filter chips start at the right edge in Persian
  const all = await page.locator('[aria-label="همه"]').first().boundingBox();
  const fav = await page.locator('[aria-label="علاقه‌مندی‌ها"]').first().boundingBox();
  assert.ok(all.x > fav.x, 'first chip is on the right');
  // ...and line up with the search box above them (its right edge is the content edge)
  const box = await page.locator('input').first().evaluate((el) => el.parentElement.getBoundingClientRect().right);
  assert.ok(Math.abs(all.x + all.width - box) < 6, 'first chip aligns with content edge: chip ' + (all.x + all.width) + ' vs ' + box);
  // active tab pill: icon is to the RIGHT of its label
  const pill = page.locator('[data-testid="tab-home"] > div').first();
  const iconBox = await pill.locator('i').boundingBox();
  const labelBox = await pill.locator('span').first().boundingBox();
  assert.ok(iconBox.x > labelBox.x, 'icon right of label');
  // body text defaults to right alignment in Persian
  const aligns = await page.evaluate(() => [...document.querySelectorAll('span')].filter((e) => /[\u0600-\u06FF]/.test(e.textContent)).map((e) => getComputedStyle(e).textAlign));
  assert.ok(aligns.length > 3 && aligns.every((a) => a === 'right' || a === 'center'), 'persian text aligned right: ' + [...new Set(aligns)]);
});


await browser.close();
console.log(`\n[browser] ${passed} passed, ${failures.length} failed`);
if (failures.length) { console.log('Failed:', failures.join('; ')); process.exit(1); }
